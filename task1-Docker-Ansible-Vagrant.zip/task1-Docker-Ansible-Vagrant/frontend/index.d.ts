declare module '*.jpg';
declare module '*.svg';