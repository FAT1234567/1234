import { AsyncThunkPayloadCreator } from '@reduxjs/toolkit';

/*
* Аналогично reset user items
* */

export const resetUserTradesOperation: AsyncThunkPayloadCreator<unknown> = async () => {};