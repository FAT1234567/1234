export const UPLOAD_PATH = `./uploads/`;
export const MOCK_USERS_COUNT = 20;
export const MOCK_USER_MAX_ITEMS = 30;
