export const MAX_ITEM_PHOTOS = 5;
export const PHONE_REGEX = /^[0-9]{10}$/;
export const AVAILABLE_PHOTO_EXTENSIONS = [`.jpeg`, `.jpg`, `.png`];
export const PAGE_SIZE = 20;
