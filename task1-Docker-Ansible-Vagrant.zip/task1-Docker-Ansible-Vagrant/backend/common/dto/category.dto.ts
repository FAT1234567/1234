export class CategoryDto {
  id: number;
  name: string;
}
