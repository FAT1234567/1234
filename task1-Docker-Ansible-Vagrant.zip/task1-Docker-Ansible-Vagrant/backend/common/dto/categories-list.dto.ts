import { CategoryDto } from '#server/common/dto/category.dto';

export class CategoriesListDto extends Array<CategoryDto> {}
