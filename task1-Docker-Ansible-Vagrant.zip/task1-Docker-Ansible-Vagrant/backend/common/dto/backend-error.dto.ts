export class BackendErrorDto {
  statusCode: number;
  message: string;
  error?: string;
}
